function adicionandoNome(){
    nome = document.getElementById("formularioNome").value
    resultadoDiv = document.getElementById
}