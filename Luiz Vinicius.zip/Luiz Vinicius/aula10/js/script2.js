const pesso={};
function mostrar(){
    let resultrado = document.getElementById('resultado')

    console.log(resultado);

    resultado.style.display ="block"
    let nome = docuyment.getElementById('nome').value;
    let email = document.getElementById('email').value;
    let senha = document.getElementById('senha').value;
    let  = document.getElementById('data').value;
    let apelido = document.getElementById('apelido').value;

}